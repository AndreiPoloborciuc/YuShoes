let images = ["https://images.unsplash.com/photo-1542291026-7eec264c27ff?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80", "https://images.unsplash.com/photo-1637844528612-064026615fcd?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80", "https://images.unsplash.com/photo-1552346154-7841f684d259?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80", "https://images.unsplash.com/photo-1612724271076-24c0a3bade29?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1925&q=80", "https://images.unsplash.com/photo-1549298916-b41d501d3772?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2012&q=80", "https://images.unsplash.com/photo-1518002171953-a080ee817e1f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80", "https://wallpaperaccess.com/full/6324752.jpg", "https://wallpaperaccess.com/full/1450241.jpg", "https://wallpaperaccess.com/full/1450244.jpg", "https://wallpaperaccess.com/full/1252105.jpg", "https://images.unsplash.com/photo-1661152655333-7b5275ad6baa?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80"]


const headerDiv = document.querySelector("#header-div")

let slideImg = 0
headerDiv.style.backgroundImage = `url(${images[slideImg]})`

function updateSlider() {
    headerDiv.style.backgroundImage = `url(${images[slideImg]})`;
}

const intervalX = setInterval(() => {
    slideImg = slideImg >= images.length - 1 ? 0 : slideImg + 1;
    updateSlider();
}, 4000)



const weatherDisplay = document.getElementById("meteo");

function getWeatherByCoordinates(latitude, longitude) {
  const apiKey = "21952e504c317bb839126494bf193a15";
  const apiUrl = `https://api.openweathermap.org/data/2.5/weather?lat=${latitude}&lon=${longitude}&appid=${apiKey}`;

  fetch(apiUrl)
    .then(response => response.json())
    .then((data) => {
      weatherDisplay.innerHTML = `
        <div class='show-meteo'>
          <h2>${data.name}, ${data.sys.country}</h2>
          <h1>${Math.round(data.main.temp - 273.15)}°C</h1>
          <p>${data.weather[0].description}</p>
        </div>
      `;
    })
    .catch((error) => {
      console.error("Eroare la obținerea datelor meteo:", error);
      weatherDisplay.innerHTML = "<p>Ne pare rău, nu am putut obține datele meteo.</p>";
    });
}

if ("geolocation" in navigator) {
  navigator.geolocation.getCurrentPosition((position) => {
    const latitude = position.coords.latitude;
    const longitude = position.coords.longitude;

    getWeatherByCoordinates(latitude, longitude);
  }, (error) => {
    console.error("Eroare la obținerea coordonatelor geografice:", error.message);
    weatherDisplay.innerHTML = "<p>Ne pare rău, nu am putut obține coordonatele geografice.</p>";
  });
} else {
  console.error("Geolocația nu este suportată în acest browser.");
  weatherDisplay.innerHTML = "<p>Geolocația nu este suportată în acest browser.</p>";
}


const cartBtn = document.getElementById("cartBtn")
const cartMenu= document.getElementById("cartMenu")
cartBtn.addEventListener("click", () => {
    cartMenu.style.width = cartMenu.style.width === "0vw" ? "50vw" : "0vw"
    cartMenu.style.padding = cartMenu.style.padding === "0px" ? "100px" : "0px"
})



const burgerBtn = document.getElementById("burgerBtn")
const burgerMenu = document.getElementById("burgerMenu") 

burgerBtn.addEventListener("click", () => {
    burgerMenu.style.width = burgerMenu.style.width === "0vw" ? "50vw" : "0vw"
    burgerMenu.style.padding = burgerMenu.style.padding === "0px" ? "50px" : "0px"
    
})


const catalog = document.querySelector("#catalog")

let shoes = [
    {
        id: 1,
        brand: "Addidas",
        pret: 3500,
        culoare: "Alb",
        marime: 40,
        image: "https://images.asos-media.com/products/adidas-originals-3mc-trainers-in-triple-white/10966136-2?$n_480w$&wid=476&fit=constrain"
    },
    {
        id: 2,
        brand: "Addidas",
        pret: 3100,
        culoare: "Negru",
        marime: 43,
        image: "https://images.asos-media.com/products/adidas-originals-handball-spezial-gum-sole-trainers-in-black/203845843-2?$n_480w$&wid=476&fit=constrain"
    },
    {
        id: 3,
        brand: "Addidas",
        pret: 2100,
        culoare: "Maro",
        marime: 43,
        image: "https://images.asos-media.com/products/adidas-originals-hyperturf-trainers-in-brown/203411993-2?$n_480w$&wid=476&fit=constrain"
    },
    {
        id: 4,
        brand: "Addidas",
        pret: 2600,
        culoare: "Gri",
        marime: 41,
        image: "https://images.asos-media.com/products/adidas-originlas-ozweego-trainers-in-triple-grey/203695238-2?$n_480w$&wid=476&fit=constrain"
    },
    {
        id: 5,
        brand: "Puma",
        pret: 2500,
        culoare: "Alb",
        marime: 42,
        image: "https://images.asos-media.com/products/puma-roma-amore-trainers-in-white/13960373-2?$n_480w$&wid=476&fit=constrain"
    },
    {
        id: 6,
        brand: "Puma",
        pret: 1100,
        culoare: "Maro",
        marime: 44,
        image: "https://images.asos-media.com/products/puma-slipstream-suede-trainers-in-desert-tan/204342626-2?$n_480w$&wid=476&fit=constrain"
    },
    {
        id: 7,
        brand: "Puma",
        pret: 2000,
        culoare: "Alb",
        marime: 39,
        image: "https://images.asos-media.com/products/puma-roma-amore-trainers-in-white/13960373-2?$n_480w$&wid=476&fit=constrain"
    },
    {
        id: 8,
        brand: "Nike",
        pret: 4000,
        culoare: "Alb",
        marime: 40,
        image: "https://images.asos-media.com/products/nike-air-more-uptempo-trainers-in-grey/204078697-2?$n_480w$&wid=476&fit=constrain"
    },
    {
        id: 9,
        brand: "Nike",
        pret: 4200,
        culoare: "Negru",
        marime: 43,
        image: "https://images.asos-media.com/products/nike-react-vision-trainers-in-triple-black/202281389-2?$n_480w$&wid=476&fit=constrain"
    },
    {
        id: 10,
        brand: "New Balance",
        pret: 4500,
        culoare: "Alb",
        marime: 41,
        image: "https://images.asos-media.com/products/new-balance-530-trainers-in-white-and-pink/204470742-2?$n_480w$&wid=476&fit=constrain"
    },
    {
        id: 11,
        brand: "New Balance",
        pret: 3900,
        culoare: "Negru",
        marime: 43,
        image: "https://images.asos-media.com/products/new-balance-running-fresh-foam-1880-trainers-in-black/203664268-2?$n_480w$&wid=476&fit=constrain"
    },
    {
        id: 12,
        brand: "New Balance",
        pret: 4900,
        culoare: "Alb",
        marime: 43,
        image: "https://images.asos-media.com/products/new-balance-530-trainers-in-white-and-grey/204470705-2?$n_480w$&wid=476&fit=constrain"
    },
]


shoes.forEach((shoe) => {
    
    catalog.innerHTML += `
       <div class='shoes'>
              <img src='${shoe.image}'>
            <div>
               <h1> ${shoe.brand}</h1>
               <h3> ${shoe.culoare}</h3>
               <h4>Marimea ${shoe.marime}</h4>
               <p> ${shoe.pret} MDL </p>
               <button class='cart-btn' onclick='addToCart(${shoe.id})'> Adauga in cos </button>
            </div>
        </div>
        `
    
})


if(cartArray = []){
    cartMenu.innerHTML += `<h1 id ='cosGol'> Cosul tau este gol !!!</h1>`
}



function addToCart(id){
    if(cartArray.find(shoe => shoe.id === id)){
        alert("Este deja in cos !!!")
        return
    }
    cartArray.push(shoes.find(shoe => shoe.id === id))
    golesteCos()
}

function golesteCos() {
    cartMenu.innerHTML = ""
    cartArray.forEach(shoe => {
        cartMenu.innerHTML += `<div> <img src='${shoe.image}'</img> <h1>${shoe.brand}</h1><h3>${shoe.culoare}</h3><h3> Marimea: ${shoe.marime}</h3><h4>${shoe.pret} MDL</h4></div>`
    })

    cartMenu.innerHTML += `<button id="golesteCosul">Goleste cosul</button>`

    let golesteCosulBTN = document.getElementById("golesteCosul")
    golesteCosulBTN.addEventListener("click", () => {
        cartArray = []
        golesteCos()
 
    })
}




let searchResult = document.querySelector("#search-result")
let search = document.getElementById("search")
let close = document.getElementById("close")


search.addEventListener("keyup", (e) => searchShoe(e))
function searchShoe(e) {
    if (e.key === "Enter") {
        const userSearch = e.target.value.toLowerCase();
        const searchResults = shoes.filter((shoe) => {
            const fullname = shoe.brand.toLowerCase();
            const search = userSearch.split(" ");
            for (let i = 0; i < search.length; i++) {
                if (fullname.includes(search[i])) {
                    return true
                }
            }
            return false
        });

        searchResult.innerHTML = "";
        searchResults.forEach((shoe) => {
            searchResult.innerHTML += `
                <div class='shoeSearch'>
                    <img src='${shoe.image}'>
                    <div>
                       <h3>${shoe.brand}</h3>
                       <h4>${shoe.culoare}</h4>
                       <p>${shoe.pret} MDL</p>
                       <button class='cart-btn' onclick='addToCart(${shoe.id})'>Adaugă în coș</button>
                    </div>
                </div>
            `;
        });

            searchResult.style.height = "600px"
            searchResult.style.padding = "50px"
            close.style.display = "flex"
            headerDiv.style.filter = "blur(4px)"
    }
}


close.addEventListener("click", () => {
    searchResult.style.height = "0px";
    searchResult.style.padding = "0px";
    close.style.display = "none";
    headerDiv.style.filter = "blur(0px)"
});



const filtru = document.querySelectorAll(".filtru")
const optiuni = document.querySelectorAll(".optiuni")

filtru.forEach((filtru1, idx) => {
    filtru1.addEventListener("click", () => {
        optiuni[idx].style.height = optiuni[idx].style.height === "auto" ? "0px" : "auto"
        optiuni[idx].style.padding = optiuni[idx].style.padding === "10px" ? "0px" : "10px"
        filtru1.firstElementChild.src = filtru1.firstElementChild.src === "https://iconmonstr.com/wp-content/g/gd/makefg.php?i=../releases/preview/7.2.0/png/iconmonstr-caret-up-lined.png&r=223&g=226&b=219"
            ? "https://iconmonstr.com/wp-content/g/gd/makefg.php?i=../releases/preview/7.2.0/png/iconmonstr-caret-down-lined.png&r=223&g=226&b=219"
            : "https://iconmonstr.com/wp-content/g/gd/makefg.php?i=../releases/preview/7.2.0/png/iconmonstr-caret-up-lined.png&r=223&g=226&b=219"
    })
})


const DelaInp = document.querySelector("#de_la")
const PanaLaInp = document.querySelector("#pana_la")
const brandCheckboxes = document.getElementsByName("brand")
const colorCheckboxes = document.getElementsByName("culoare")
const marime = document.getElementById("marime")


const filters =
    {
        brands: [],
        pretMin: 0,
        pretMax: 0,
        colors: [],
        marimeAd : 0
    }
   
DelaInp.addEventListener("input", () => {
    filters.pretMin = Number(DelaInp.value)
    smartFilter(shoes, filters)
    
})

PanaLaInp.addEventListener("input", () => {
    filters.pretMax =Number(PanaLaInp.value)
    smartFilter(shoes, filters)

})


brandCheckboxes.forEach(checkbox => {
    checkbox.addEventListener("click", () =>{
        if(checkbox.checked){
            filters.brands.push(checkbox.value)
        }else{
            filters.brands.splice(filters.brands.indexOf(checkbox.value), 1)
        }

        smartFilter(shoes, filters)
        
    })
})

colorCheckboxes.forEach(checkbox => {
    checkbox.addEventListener("click", () =>{
        if(checkbox.checked){
            filters.colors.push(checkbox.value)
        }else{
            filters.colors.splice(filters.colors.indexOf(checkbox.value), 1)
        }

        smartFilter(shoes, filters)

        
    })

})

marime.addEventListener("input", () => {
    filters.marimeAd = Number(marime.value)
    smartFilter(shoes, filters)

})



function smartFilter(data, filters) {

    let filteredData = data;

    if (filters.pretMin > 0) {
        filteredData = filteredData.filter(item => item.pret >= filters.pretMin);
    }

    if (filters.pretMax > 0) {
        filteredData = filteredData.filter(item => item.pret <= filters.pretMax);
    }

    if (filters.brands.length > 0) {
        filteredData = filteredData.filter(item => filters.brands.includes(item.brand));
    }

    if (filters.colors.length > 0) {
        filteredData = filteredData.filter(item => filters.colors.includes(item.culoare));
    }

    if (filters.marimeAd > 0) {
        filteredData = filteredData.filter(item => item.marime === filters.marimeAd);
    }


    smartDisplay(filteredData, catalog)
}


function smartDisplay(filteredData, el){
    el.innerHTML = ""

    filteredData.forEach(item =>{
        el.innerHTML += `
        <div class='shoes'>
            <img src='${item.image}'>
            <div>
               <h3> ${item.brand}</h3>
               <h4> ${item.culoare}</h4>
               <p>Marimea ${item.marime}</p>
               <p> ${item.pret} MDL </p>
               <button class='cart-btn' onclick='addToCart(${item.id})'> Adauga in cos </button>
            </div>
        </div>
        `
    })
}